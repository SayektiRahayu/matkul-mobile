package com.example.percobaan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
